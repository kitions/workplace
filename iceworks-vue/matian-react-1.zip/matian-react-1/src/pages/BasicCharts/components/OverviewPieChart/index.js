import OverviewPieChart from './OverviewPieChart';

export default OverviewPieChart;
