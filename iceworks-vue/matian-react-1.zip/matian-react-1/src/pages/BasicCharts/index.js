import BasicCharts from './BasicCharts';

export default BasicCharts;
