import TermsInfo from './TermsInfo';

export default TermsInfo;
