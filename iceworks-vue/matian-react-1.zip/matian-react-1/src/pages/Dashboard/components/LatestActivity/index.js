import LatestActivity from './LatestActivity';

export default LatestActivity;
