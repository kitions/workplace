import SelectLang from './SelectLang';

export default SelectLang;
