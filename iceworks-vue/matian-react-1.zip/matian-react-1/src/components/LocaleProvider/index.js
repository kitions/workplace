import LocaleProvider from './LocaleProvider';

export default LocaleProvider;
