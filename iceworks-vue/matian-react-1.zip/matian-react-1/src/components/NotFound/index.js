import NotFound from './NotFound';

export default NotFound;
