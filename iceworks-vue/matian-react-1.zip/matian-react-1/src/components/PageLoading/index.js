import PageLoading from './PageLoading';

export default PageLoading;
