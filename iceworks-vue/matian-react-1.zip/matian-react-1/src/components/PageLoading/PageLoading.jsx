import React from 'react';
import { Loading } from '@alifd/next';

export default () => (
  <div style={{ paddingTop: 200, textAlign: 'center' }}>
    <Loading color="#fff" />
  </div>
);
