export default {
  // 项目列表
  'app.list.project.overview.all': '所有任务',
  'app.list.project.overview.unsolved': '未解决',
  'app.list.project.overview.pending': '处理中',
  'app.list.project.overview.solved': '已解决',
  'app.list.project.table.title': '项目列表',
};
