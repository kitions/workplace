export default {
  // 项目列表
  'app.list.project.overview.all': 'All Task',
  'app.list.project.overview.unsolved': 'Unsolved',
  'app.list.project.overview.pending': 'Pending',
  'app.list.project.overview.solved': 'Solved',
  'app.list.project.table.title': 'Project List',
};
